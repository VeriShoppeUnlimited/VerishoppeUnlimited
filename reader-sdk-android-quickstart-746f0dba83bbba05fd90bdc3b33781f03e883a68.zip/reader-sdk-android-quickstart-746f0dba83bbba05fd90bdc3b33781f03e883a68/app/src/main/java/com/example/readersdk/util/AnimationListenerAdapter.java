package com.example.readersdk.util;

import android.animation.Animator;

public abstract class AnimationListenerAdapter implements Animator.AnimatorListener {
  @Override public void onAnimationStart(Animator animation) {

  }

  @Override public void onAnimationEnd(Animator animation) {

  }

  @Override public void onAnimationCancel(Animator animation) {

  }

  @Override public void onAnimationRepeat(Animator animation) {

  }
}
